"""
Lambda Handlers for Loan Eligibility Engine
"""
