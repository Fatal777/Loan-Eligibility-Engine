"""
Utility functions for Loan Eligibility Engine
"""
