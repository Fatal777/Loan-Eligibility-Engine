"""
Loan Eligibility Engine - AWS Lambda Handlers
"""
